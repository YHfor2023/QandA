var data = require('./api/data.js')

module.exports = {
  getData: data.getData,
  setData: data.setData
}