@extends('layouts/gateway')
<style>
    .wechat-image{
        width: 150px;
        height: 150px;
    }
</style>
@section('content')
    <div class="container">
        <div class="jumbotron">
            <div>
                <image class="wechat-image" src="http://image.kucaroom.com/gh_7cda07475bf9_430.jpg"></image>
            </div>
            <h3>校园小情书</h3>
            <p>校园小情书，在巨人林立的时代，我们不指望能够站在巨人的肩膀上，但是我们能够联合在一起成为一个小巨人，创造美好的事物。</p>
        </div>
    </div>
@stop