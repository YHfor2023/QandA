<!DOCTYPE html>
<html lang="en" >
<head>
    <meta charset="UTF-8">
    <title>宝连,祝你生日快乐</title>
    <link rel="stylesheet" href="{{asset('css/flower.css')}}">
    <link href="https://cdn.bootcss.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>


<canvas id="canvas"></canvas>

<div class="block-audio">
    <audio class="exp" src="{{asset('music/exp1.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp1.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp1.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp2.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp2.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp2.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp3.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp3.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp3.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp4.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp4.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp4.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp5.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp5.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp5.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp6.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp6.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp6.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp7.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp7.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp7.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp8.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp8.mp3')}}" controls></audio>
    <audio class="exp" src="{{asset('music/exp8.mp3')}}" controls></audio>
    <audio class="launch" src="{{asset('music/launch1.mp3')}}" controls></audio>
    <audio class="launch" src="{{asset('music/launch1.mp3')}}" controls></audio>
    <audio class="launch" src="{{asset('music/launch2.mp3')}}" controls></audio>
    <audio class="launch" src="{{asset('music/launch2.mp3')}}" controls></audio>
    <audio class="launch" src="{{asset('music/launch3.mp3')}}" controls></audio>
    <audio class="launch" src="{{asset('music/launch3.mp3')}}" controls></audio>
    <audio class="launch" src="{{asset('music/launch4.mp3')}}" controls></audio>
    <audio class="launch" src="{{asset('music/launch4.mp3')}}" controls></audio>
    <audio class="launch" src="{{asset('music/launch5.mp3')}}" controls></audio>
    <audio class="launch" src="{{asset('music/launch5.mp3')}}" controls></audio>
</div>

<script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript" src="{{asset('js/flower.js')}}"></script>

</body>
</html>
