@extends('layouts/admin')
@section('content')
    <div class="x-body layui-anim layui-anim-up" id="app">
      部署教程
    </div>

@endsection