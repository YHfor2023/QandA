# 校园小情书

校园小情书是一个开源项目，你可以使用叶子的后台服务，也可以自己搭建后台服务，该小程序部署上线是需要微信认证小程序的，需要选择微信小程序类目为社交-论坛类目。本文档为独立部署小情书后台服务的教程。

#### 有空帮忙点一下右上角的start，谢谢

如需要部署帮助，联系微信：bingbing_ou

前端源码在这里：https://github.com/oubingbing/school_wechat

扫码进入体验

<img src="http://article.qiuhuiyi.cn/Fthvoe308wnXc0vy0IsrY9GKmzx3"  width="100px" />

#### 功能
- 表白墙
- 卖舍友
- 步数旅行
- 步数排行榜
- 情侣脸
- 漫画脸
- 个人主页
- 私信
- 站内消息
- 今日话题
- 评论点赞收藏


## 项目环境要求

    PHP 7.0以上
    
    MySQL 5.7
    

## [宝塔部署（推荐）](https://github.com/oubingbing/wechatAlliance/blob/master/bt.md "宝塔部署（推荐）")

## [微信云部署（网友的重构版本）](https://github.com/lx164/SayLove "微信云部署（网友的重构版本）")