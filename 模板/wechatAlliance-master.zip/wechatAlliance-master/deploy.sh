cd /var/www/wechatAlliance

git pull origin master