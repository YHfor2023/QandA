<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/6/28 0028
 * Time: 9:28
 */

namespace Tests\Unit;


use Tests\TestCase;

class LoginTest extends TestCase
{

}